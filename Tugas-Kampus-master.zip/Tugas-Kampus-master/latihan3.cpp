#include <iostream>
// I.S Program menampilkan data
// F.S menampilkan hasil hitung variable a dan b dengan operator tambah
 
using namespace std;

int main() {


	int a, b; // buat variable a dan b dengan type intejer
	int c;  // buat variable c dengan type intejer

	float f;  // buat variable a dan b dengan type float

	a = 10;  // berikan nilai variable a dengan nilai 10
	b = 20;  // berikan nilan variable b dengan nilai  20
	c = a+b; // tambahkan variable a dan b pada variable c

	cout << c << endl; // tampilkan variable c
	f = 70.0/3.0; 
	cout << f << endl;
	
	return 0;

	 
}

 