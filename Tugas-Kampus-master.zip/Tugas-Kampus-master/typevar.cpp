#include <iostream>
// I.S Program Mencari ukuran type data
// F.S Menampilkan ukuran type data

using namespace std;

int main() {
 
 	cout << "Ukuran Char : " << sizeof(char) << endl; // menampilkan ukuran type data charcter
 	cout << "Ukuran Int : " << sizeof(int) << endl; // menampilkan ukuran type data Intejer
 	cout << "Ukuran Short Int : " << sizeof(short int) << endl; // menampilkan ukuran type data shor int
 	cout << "Ukuran Long Int : " << sizeof(long int) << endl; // menampilkan ukuran type data long int
 	cout << "Ukuran Float : " << sizeof(float) << endl; // menampilkan ukuran type data  float
 	cout << "Ukuran Double : " << sizeof(double) << endl; // menampilkan ukuran type data double
 	cout << "Ukuran Wchar_t : " << sizeof(wchar_t) << endl;  // menampilkan ukuran type data wchar t
	
	return 0;

	 
}

 