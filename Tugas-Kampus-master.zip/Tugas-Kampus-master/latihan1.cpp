#include <iostream>
// I.S Program membuat variable
// F.S Menampilkan hasil tambah variable a dan b

using namespace std;

int main() {
	int a, b; // membuat variable a dan be dengan type integer
	int c; // membuat variable c dengan type integer

	float f; // membuat variable f denga type float

	a = 10; // berikan variable a dengan nilai 10
	b = 20; // berikan variable b dengan nilai 20
	c = a+b; // berika variable c dengan menambahkan variable a dan b

	cout << c << endl; // tampilkan hasil hitung a dan b
	f = 70.0/3.0;
	cout << f << endl;
	
	return 0;

	 
}

 
