#include <iostream> 
// I.S Program Menghitung character
// F.S Menampilkan ukuran character

using namespace std;

int main() {
	char str[] = "hello c++"; // buat variable str dengan type car
	
	cout << "Value of str is : " << str << endl;  // tampilkan variable stre
	 
} 